# Don't Make AI Think - Complete Book Reference

## Download Status

✅ **Chapter 1: The Invisible Users** - `chapter-01-the-invisible-users.md`  
✅ **Chapter 2: How AI Reads (vs. How Humans Read)** - `chapter-02-how-ai-reads.md`  
✅ **Chapter 3: Guiding Principles** - `chapter-03-guiding-principles.md`  
⏳ **Chapters 4-10** - Being created...

## Complete Chapter List

All 10 chapters from our conversation are being created as individual downloadable files:

### Foundation Chapters (Available Now)
1. **The Invisible Users** - Who AI agents are and why they matter
2. **How AI Reads** - The technical differences in how AI processes web content
3. **Guiding Principles** - The four core principles for dual-audience design

### Implementation Chapters (Creating Now)
4. **Content Architecture for Machines** - Practical patterns for common page types
5. **Metadata That Works** - Schema.org and structured data implementation
6. **The Navigation Problem** - Sitemaps, links, and site discovery
7. **The JavaScript Challenge** - Making modern web apps AI-readable
8. **Testing with AI Agents** - Validation methodologies and tools
9. **Common Anti-Patterns** - Mistakes to avoid and how to fix them
10. **Implementation Roadmap** - Your 10-week plan from audit to deployment

## How to Use These Files

### For Quick Learning
- Read Chapters 1-3 for understanding
- Skip to Chapter 10 for implementation plan
- Reference Chapters 4-9 as needed during implementation

### For Complete Mastery
- Read all chapters in order
- Complete the exercises and tests
- Implement the patterns systematically

### For Team Training
- Share Chapter 1 with stakeholders (the "why")
- Share Chapters 4-6 with developers (the "how")
- Share Chapter 10 with project managers (the "when")

## Key Concepts by Chapter

### Chapter 1: The Invisible Users
- AI agents visiting your site right now
- Economic impact: £2M redesign invisible to AI
- The morning-after test
- Three types of traffic: search, direct, AI recommendations

### Chapter 2: How AI Reads
- Three types of AI readers: parsers, browsers, vision models
- DOM order = reading order
- Token budgets limit what AI can process
- CSS styling is invisible to parsers

### Chapter 3: Guiding Principles
1. Semantic clarity over visual clarity
2. Structure reveals intent
3. Metadata makes promises explicit
4. Redundancy serves different consumers

### Chapter 4: Content Architecture
- Article/blog post structure
- Product page patterns
- Navigation menus
- FAQ sections
- Contact pages
- Data tables

### Chapter 5: Metadata
- JSON-LD vs microdata
- Organization/LocalBusiness schema
- Product schema
- Article schema
- FAQ schema
- When NOT to use metadata

### Chapter 6: Navigation
- XML sitemap generation
- Descriptive link text
- Internal linking strategy
- Breadcrumbs
- Hub and spoke patterns

### Chapter 7: JavaScript
- Progressive enhancement
- Server-side rendering (SSR)
- Static site generation (SSG)
- SPA challenges
- Infinite scroll solutions

### Chapter 8: Testing
- The morning-after test (detailed)
- Headless browser testing with Puppeteer
- Schema.org validation
- Automated test suites
- Continuous monitoring

### Chapter 9: Anti-Patterns
- Visual-only information
- Content in images
- Generic link text ("click here")
- Broken heading hierarchy
- JavaScript-only navigation
- Hidden content
- Outdated sitemaps
- Inconsistent Schema.org
- Forms without labels
- Table abuse
- Content in iframes
- PDF-only content
- Auto-playing content

### Chapter 10: Implementation Roadmap
- **Week 1**: Assessment (15-25 priority pages)
- **Weeks 2-3**: Quick wins (28 hours - Schema.org, headings, links, alt text)
- **Weeks 4-6**: Structural improvements (40-48 hours - SSR, navigation, progressive enhancement)
- **Weeks 7-8**: Content patterns (28 hours - semantic HTML, forms, tables)
- **Week 9**: Testing and validation (20 hours)
- **Week 10+**: Ongoing maintenance (30 min/week)
- **Real case study**: Automotive client, 85 hours, 60% increase in AI recommendations

## Quick Reference Cards

### The Morning-After Test
1. View page source (not inspect element)
2. Copy the HTML
3. Paste into ChatGPT/Claude
4. Ask: "What is this page about? What actions can I take?"
5. If AI can't answer, neither can invisible users

### Essential HTML Patterns
```html
<!-- Semantic structure -->
<article>
  <header>
    <h1>Page Title</h1>
    <time datetime="2024-03-20">20 March 2024</time>
  </header>
  <section>
    <h2>Section Title</h2>
    <p>Content...</p>
  </section>
</article>

<!-- Navigation -->
<nav aria-label="Main navigation">
  <ul>
    <li><a href="/">Home</a></li>
  </ul>
</nav>

<!-- Product with Schema.org -->
<article itemscope itemtype="https://schema.org/Product">
  <h1 itemprop="name">Product Name</h1>
  <data itemprop="price" value="99">£99</data>
</article>
```

### Essential Tests
1. **Disable JavaScript** - Does content still appear?
2. **View source** - Is content in HTML?
3. **Heading outline** - Does hierarchy make sense?
4. **Link audit** - Are links descriptive?
5. **Schema validation** - Does it pass Google's test?

### Essential Tools
- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema.org Validator: https://validator.schema.org
- Lighthouse (Chrome DevTools)
- WAVE: https://wave.webaim.org

## Implementation Checklist

### Phase 1: Quick Wins (Weeks 2-3)
- [ ] Add Organization Schema.org to homepage
- [ ] Add Product/Service schema to top 10 pages
- [ ] Fix heading hierarchy (h1 → h2 → h3)
- [ ] Replace generic link text ("click here" → descriptive)
- [ ] Add alt text to all images

### Phase 2: Structure (Weeks 4-6)
- [ ] Create or update sitemap.xml
- [ ] Add semantic nav elements
- [ ] Implement breadcrumbs
- [ ] Add progressive enhancement to interactive features
- [ ] Consider SSR for JavaScript-heavy pages

### Phase 3: Content (Weeks 7-8)
- [ ] Use semantic HTML (article, section, aside)
- [ ] Convert visual lists to ul/ol
- [ ] Add proper form labels
- [ ] Structure tables correctly
- [ ] Use definition lists for key-value pairs

### Phase 4: Testing (Week 9)
- [ ] Set up automated testing
- [ ] Run morning-after test on all priority pages
- [ ] Validate all Schema.org markup
- [ ] Document standards for team

### Phase 5: Maintenance (Ongoing)
- [ ] Weekly: Review automated tests
- [ ] Monthly: Audit new content
- [ ] Quarterly: Comprehensive review

## ROI Calculator

Based on real client data:

**Investment**:
- Assessment: 8 hours
- Implementation: 60-80 hours
- Testing: 12 hours
- Total: 80-100 hours

**Returns** (within 3 months):
- AI recommendations: +40-60%
- Organic search traffic: +25-35%
- Voice search queries: +100%
- Time to market for new pages: -30% (with templates)

**Example**: Automotive client
- Cost: £12,000 (85 hours consulting + internal dev time)
- Previous investment: £2M redesign (invisible to AI)
- Result: 60% increase in AI visibility, traffic doubled from voice search

## Common Questions

**Q: Do I need to rebuild my entire site?**  
A: No. Start with 15-25 priority pages (20% of pages = 80% of traffic)

**Q: Will this break my design?**  
A: No. Semantic HTML can be styled exactly like divs. Visual design unchanged.

**Q: How long does implementation take?**  
A: 9 weeks for comprehensive implementation, or 3 weeks for quick wins only

**Q: What if we use a JavaScript framework?**  
A: Implement SSR (server-side rendering) for public pages, keep SPA for authenticated areas

**Q: How do I convince stakeholders?**  
A: Show them the morning-after test on your homepage. When AI can't answer "what do we do?" that's compelling

**Q: What's the minimum viable implementation?**  
A: Schema.org on homepage + proper headings + descriptive links = 28 hours, significant improvement

## Next Steps

1. Download Chapters 1-3 (available now)
2. Download Chapters 4-10 (being created)
3. Read Chapter 1 to understand the problem
4. Read Chapter 10 for the implementation plan
5. Start with Phase 1 quick wins
6. Use remaining chapters as reference during implementation

## Support Resources

All chapters include:
- Real code examples (copy-paste ready)
- Before/after comparisons
- Testing methodologies
- Common pitfalls and solutions

---

**Note**: This book represents 25 years of web development experience and real client work with global companies. The patterns and recommendations are battle-tested, not theoretical.

*Tom Harris, Principal Consultant, Digital Domain Technologies Ltd*
